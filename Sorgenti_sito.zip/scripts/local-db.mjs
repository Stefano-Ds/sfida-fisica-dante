import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
export function environment(){
  const sql=new DatabaseSync(':memory:');
  for(const file of readdirSync(new URL('../drizzle',import.meta.url)).filter(s=>s.endsWith('.sql'))){
    sql.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
  }
  const DB={
    prepare(query){
      return {
        bind(...args){
          return {
            async first(){return sql.prepare(query).get(...args)||null;},
            async run(){const result=sql.prepare(query).run(...args);return {meta:{changes:Number(result.changes)}};},
          };
        },
      };
    },
    async batch(statements){
      sql.exec('BEGIN');
      try{const values=[];for(const statement of statements)values.push(await statement.run());sql.exec('COMMIT');return values;}
      catch(error){sql.exec('ROLLBACK');throw error;}
    },
  };
  return {IP_SECRET:'local-test-only',DB,sql};
}
