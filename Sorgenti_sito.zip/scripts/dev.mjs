import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import app from '../worker.js';
import { environment } from './local-db.mjs';
const env=environment();
createServer(async(req,res)=>{const chunks=[];for await(const c of req)chunks.push(c);const headers={...req.headers,'CF-Connecting-IP':'127.0.0.1'};const input=new Request('http://localhost:4173'+req.url,{method:req.method,headers,...(req.method==='GET'?{}:{body:Buffer.concat(chunks)})});const result=await app.fetch(input,env);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));}).listen(4173,'127.0.0.1',()=>console.log('Local: http://localhost:4173'));

