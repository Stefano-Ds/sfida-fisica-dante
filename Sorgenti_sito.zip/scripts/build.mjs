import { mkdir, readFile, writeFile } from 'node:fs/promises';
const root=new URL('../',import.meta.url);
let code=await readFile(new URL('worker.js',root),'utf8');
for(const name of ['questions','ui','protected-file']){const source=await readFile(new URL(name+'.js',root),'utf8');code=code.replace(new RegExp('import[^;]+from \'\\./'+name+'\\.js\';'),source.replaceAll('export ',''));}
await mkdir(new URL('dist/server/',root),{recursive:true});
await writeFile(new URL('dist/server/index.js',root),code);
await mkdir(new URL('dist/.openai/',root),{recursive:true});
await writeFile(new URL('dist/.openai/hosting.json',root),await readFile(new URL('.openai/hosting.json',root)));
console.log('Worker compilato con documento protetto.');
