export const fileName = 'dispensa.pdf';
export const fileBase64 = '';
