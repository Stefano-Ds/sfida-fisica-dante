import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const attempts = sqliteTable('attempts', {
  ip: text('ip').primaryKey(),
  token: text('token').notNull(),
  questions: text('questions').notNull(),
  expires: integer('expires').notNull(),
  state: text('state').notNull(),
  blockedUntil: integer('blocked_until').notNull().default(0),
});
