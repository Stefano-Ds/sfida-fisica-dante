CREATE TABLE `attempts` (
	`ip` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`questions` text NOT NULL,
	`expires` integer NOT NULL,
	`state` text NOT NULL,
	`blocked_until` integer DEFAULT 0 NOT NULL
);
